import redis
import json
import time

# Connect to Redis
redis_client = redis.StrictRedis(host='redis', port=6379, decode_responses=True)

def store_json_in_redis():
    data_id = 1
    while True:
        # Simulated JSON data
        data = {
            "id": data_id,
            "temperature": 22 + data_id % 5,
            "humidity": 45 - data_id % 3
        }
        redis_client.set(f"data:{data_id}", json.dumps(data))
        print(f"Stored in Redis: {data}")
        data_id += 1
        time.sleep(5)  # Simulate periodic data generation

store_json_in_redis()
