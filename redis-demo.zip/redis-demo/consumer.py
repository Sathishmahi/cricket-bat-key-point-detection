import redis
from azure.iot.device import IoTHubDeviceClient, Message
import time

# Connect to Redis
redis_client = redis.StrictRedis(host='redis', port=6379, decode_responses=True)

# Connect to IoT Hub
iot_hub_connection_string = "HostName=saptialAnalysis.azure-devices.net;DeviceId=test-cam;SharedAccessKey=7RGojm3mfl4lrHcS4er7ZvuZEsWF28BrZAIoTOCvSfE="
device_client = IoTHubDeviceClient.create_from_connection_string(iot_hub_connection_string)
device_client.connect()

def send_data_to_iothub():
    while True:
        keys = redis_client.keys("data:*")  # Fetch all keys matching the pattern
        for key in keys:
            data = redis_client.get(key)
            message = Message(data)
            device_client.send_message(message)
            print(f"Sent to IoT Hub: {data}")

            # Optionally, delete the key from Redis after sending
            redis_client.delete(key)
        time.sleep(5)  # Wait before the next batch of reads

send_data_to_iothub()
